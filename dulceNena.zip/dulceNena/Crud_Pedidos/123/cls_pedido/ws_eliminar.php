<?php
 session_start();
  include("../cls_conectar2/cls_Conectar.php");
  $obj=new Conexion();
  //crear objeto de la clase
  $id_p=$_POST['codigoEliminar'];
  $sql="delete from tb_pedido where Id_Pedidos='$id_p'";
  $rsMed=mysqli_query($obj->getConexion(),$sql);
  //variable de tipo selsión
  $_SESSION["data"]=3;
  header("location: ../ws_RegisterPedido.php");
?>