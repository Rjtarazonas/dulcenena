<?php
session_start();
include("../cls_conectar2/cls_Conectar.php");
$obj=new Conexion();
//recuperar valores de lo scontrolotradoresn del forms "post"
$id_p=$_POST['ID'];
$direc_p=$_POST['Direccion_Pedido'];
$fecha_h=$_POST['Fecha_Hora'];
$est=$_POST['Estado'];
$met_p=$_POST['Metodo_Pago'];
$prec_f=$_POST['Precio_Final']; 

if ($id_p == 0) { //registro
    // Insertar nuevo pedido
    $sql="insert into  tb_pedido values(null,'$direc_p','$fecha_h','$est','$met_p','$prec_f')";
    $rsMed=mysqli_query($obj->getConexion(),$sql);
    header("location: ../ws_RegisterPedido.php");
    $_SESSION["data"]=1;
} else {
    // Actualizar pedido existente
    $sql="update tb_pedido set Direccion_Ped='$direc_p', Fecha_hora='$fecha_h'
                , Estado='$est', Metodo_Pago='$met_p', Precio_Final='$prec_f' WHERE Id_Pedidos='$id_p'";
    $rsMed=mysqli_query($obj->getConexion(), $sql); 
    header("location: ../ws_RegisterPedido.php");
    $_SESSION["data"]=2;
}


?>