<?php
  //iniciar sesión
  //incluir en la página actual la página cls_Conectar.php
  //.. sirve para retroceder la rutass
  include("cls_conectar2/cls_Conectar.php");
  //crear objeto de la clase
  $obj=new Conexion();

  $cod =$_POST['co']

  
    
?>