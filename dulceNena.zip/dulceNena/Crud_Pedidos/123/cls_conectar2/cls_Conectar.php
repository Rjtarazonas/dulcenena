<?php
	class Conexion
	{
		function getConexion()
		{
			$server="localhost:3306";
			$login="root";
			$pass="";
			$bdatos="pasteleria";
			$cn=mysqli_connect($server,$login,$pass,$bdatos);
			if(mysqli_connect_error()){
				echo 'error nro: '.mysqli_connect_errno();
			}
			return $cn;
		}
	}	
?>



