<?php 
   session_start();
    include("cls_conectar2/cls_Conectar.php");
    $obj=new Conexion();
    $sql="select * from tb_pedido";
    $rsMed=mysqli_query($obj->getConexion(),$sql);
 ?>
<!doctype html>
<html lang="en"> 
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Empleados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/3a7a20b9b8.js" crossorigin="anonymous"></script>
  

   <style>
      body{
        background: #F3CC97;
      }
      .bg-image {
      background: url('img/pexels-alejandro-novoa-16712064.jpg') no-repeat center center fixed;
      background-size: cover;
      }
      .modal-header{
              color:#fff;
              background: #428bca;
              display: flex;
              justify-content: center;
            }
            .help-block {
                color: red;
            }
            .form-group.has-error .form-control-label {
              color: red;
            }
            .form-group.has-error .form-control {
              border: 1px solid red;
              box-shadow: 0 0 0 0.2rem rgba(250, 16, 0, 0.18);
            }
    </style>
    </head>
  <body>
  <img src="../../../img/hambu.png" alt="Hot Burger Logo"  width="80" class="margin left mt-4">
  <h1 class='text-center mt-4'>Listado de Pedidos</h1>

  <H4 class="mt-5 text-center">Agregar un nuevo Pedido</H4>
    <div class="text-center">
<button type="button" class="btn btn-primary mt-1 m-5 vertical-center"  data-bs-toggle="modal" data-bs-target="#modalPedido"><i class="fa-solid fa-user-plus"></i>
  Agregar Pedido
  </button>
     </div>
            <!-- Modal -->
            <div class="modal fade" id="modalPedido" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Insertar Pedido</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
            <div class="modal-body">
                
                <form class="row g-4" method="post" action="cls_pedido/ws_Pedido.php" id="form-registrar">
                    <div class="col-md-4">
                        <label  class="form-label">ID</label>
                        <input type="numb" class="form-control" id="txt-ID" name="ID">
                    </div>
                    <div class="col-8">
                        <label  class="form-label">Direccion del Pedido</label>
                        <input type="text" class="form-control" id="txt-direcp" name="Direccion_Pedido">
                    </div>
                    <div class="col-6">
                        <label  class="form-label">Fecha y Hora</label>
                        <input type="text" class="form-control" id="txt-fechah" name ="Fecha_Hora">
                    </div>
                    <div class="col-6">
                        <label  class="form-label">Estado</label>
                        <input type="text" class="form-control" id="txt-estado"  name ="Estado">
                    </div>
                    <div class="col-md-6">
                        <label  class="form-label">Metodo de pago</label>
                        <input type="text" class="form-control" id="txt-metpago" name="Metodo_Pago">
                    </div>
                    <div class="col-md-6">
                        <label  class="form-label">Precio final</label>
                        <input type="text" class="form-control" id="txt-preciof" name="Precio_Final">
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary btn-save">Guardar</button>
                </div>
                </form>
                </div>
            </div>     
            </div>
            </div>
            </div>
            <table id="example" class="table table-striped dt-responsive nowrap mt-5" style="width:100%">
                <thead>
                    <tr>
                    <tr class="text-center mt-4">
                        <th>ID_Pedidos</th>
                        <th>Direccion del Pedido</th>
                        <th>Fecha y Hora</th>
                        <th>Estado</th>
                        <th>Metodo de Pago</th>
                        <th>Precio Final</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        while($row=mysqli_fetch_array($rsMed)){
                     ?>
                        <tr>
                        <tr class="text-center mt-4">
                            <td><?php echo $row[0]?></td>
                            <td><?php echo $row[1]?></td>
                            <td><?php echo $row[2]?></td>
                            <td><?php echo $row[3]?></td>
                            <td><?php echo $row[4]?></td>
							              <td><?php echo $row[5]?></td>
                            <td><button type="button" class="btn btn-warning btn-editar" data-bs-toggle="modal" data-bs-target="#modalPedido"><i class="fa-regular fa-pen-to-square"></i></button></td>
                            <td><button type="button" class="btn btn-danger btn-eliminar"><i class="fa-sharp fa-solid fa-trash"></i></button></td>

                        </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
            <form method="post" action="cls_pedido/ws_eliminar.php" id="form-eliminar">
                <input type="hidden" name="codigoEliminar" id="txt-codigo-eliminar">
           </form>

    <script src="https://kit.fontawesome.com/1da5200486.js" crossorigin="anonymous"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.7.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
      //asignar evento click a todos los botones con nombre de clase "btn-editar"
      //para esto caso usaremos JQUERY
      $(document).on("click",".btn-editar",function(){
        //variables
        let idp,direp,fechah,ests,metopago,preciofi;
        //guardar en las variables los valores de las columnas
        //según el botón editar que se seleccionado
        idp=$(this).parents("tr").find("td")[0].innerHTML;
        direp=$(this).parents("tr").find("td")[1].innerHTML;
        fechah=$(this).parents("tr").find("td")[2].innerHTML;
        ests=$(this).parents("tr").find("td")[3].innerHTML;
        metopago=$(this).parents("tr").find("td")[4].innerHTML;
        preciofi=$(this).parents("tr").find("td")[5].innerHTML;
        //mostrar en los controles los valores de las variables
        //trabajar con el atributo "ID"
        $("#txt-ID").val(idp);
        $("#txt-direcp").val(direp);
        $("#txt-fechah").val(fechah);
        $("#txt-estado").val(ests);
        $("#txt-metpago").val(metopago);
        $("#txt-preciof").val(preciofi);
      })
      //evento click para eliminar
       $(document).on("click",".btn-eliminar",function(){//cuando es clase pones antes punto y si es id va el #
        let codEmpl;
        codEmpl=$(this).parents("tr").find("td")[0].innerHTML;
        $("#txt-codigo-eliminar").val(codEmpl);


        const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
      })
      swalWithBootstrapButtons.fire({
        title: 'Seguro de eliminar al Empleado',
        text: "",
        icon: 'warning',
        showConfirmButton: true,
        showCancelButton: true,
        confirmButtonText: 'Si',
        cancelButtonText: 'No',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
        $("#form-eliminar").submit();
        }
      })
        })



      $(document).on("click","#boton-cerrar",function(){
        //restear formulario
        $("form-registrar").trigger("reset");

      })
    </script>
    <?php

     //validar si existe el atributo de tipo seción
     //sesión "data"
    if (isset($_SESSION['data']) && $_SESSION['data']==1) {
      echo "<script>  
              Swal.fire('Pedido Registrado');
            </script>";
      
    }elseif (isset($_SESSION['data']) && $_SESSION['data']==2) {
      echo "<script>  
              Swal.fire('Pedido Editado');
            </script>";
      
    }elseif (isset($_SESSION['data']) && $_SESSION['data']==3) {
      echo "<script>  
              Swal.fire('Pedido Eliminado');
            </script>";
    }
    //eliminar atributos de tipo sesión
    session_unset();
    //eliminar la sesión actual
    session_destroy();

     ?>

  </body>
</html>
