<?php
    $server= "localhost";
    $user= "root";
    $pass= "";
    $database= "pasteleria";

    $conexion= mysqli_connect ($server,$user,$pass,$database);
   
        if(!$conexion){
            echo 'No se conecto a la BD';         
        } 
?>