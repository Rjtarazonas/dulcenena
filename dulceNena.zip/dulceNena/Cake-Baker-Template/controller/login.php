<?php
   @include('conectionBD.php');
  
   $usuario = $_POST['username'];
   $contra = $_POST['password'];

   $validarLog= mysqli_query($conexion, "select * from cuenta
      where nombreusuario='$usuario' and clave='$contra'");

   if(mysqli_num_rows($validarLog) >0){
      header("location: index.php?");
      exit();
   }else{
      echo '<script>
               alert("¡Acceso denegado....verifique sus datos!");
               window.location= "index.php"

            </script>';
      exit();
   }

//control

?>