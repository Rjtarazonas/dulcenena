<?php
$error;
if(!empty($_POST['username']) && !empty($_POST['password'])){
    $username= $_POST['username'];
    $password= $_POST['password'];
    //$query = "SELECT * FROM usuario";
    if($username== "admin" && $password == "123"){
        $error = "ok";
        header("location: /Cake-Baker-Template/index.php");
        echo "Acceso aceptado";
    }else{
        $error = "Incorrecto";
    }
}else{
    $error = "vacio";
    //echo "Los datos estan vacios";
    header("location: login.php?error=$error");
}
?>